export interface iAlert {
    text: string;
    type: string;
    show: boolean;
}