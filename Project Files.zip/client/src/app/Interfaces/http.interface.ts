export interface iHttpResponse {
    message: string;
    success: boolean;
    data: any;  
}