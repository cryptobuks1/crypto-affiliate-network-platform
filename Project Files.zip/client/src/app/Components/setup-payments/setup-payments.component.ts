import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setup-payments',
  templateUrl: './setup-payments.component.html',
  styleUrls: ['./setup-payments.component.scss']
})
export class SetupPaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
