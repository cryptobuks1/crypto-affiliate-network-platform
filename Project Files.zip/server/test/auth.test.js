import mocha from 'mocha';
import chai from 'chai';

describe('it shouldn\'t give any errors', () => {
    it('attempts to do something funky', () => {

    });
});